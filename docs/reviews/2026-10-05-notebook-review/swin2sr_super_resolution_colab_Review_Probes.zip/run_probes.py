"""S2R review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, os, sys, types, zipfile, re, time
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/swin2sr_super_resolution_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import swin2sr_super_resolution_pipeline.samples as S
import swin2sr_super_resolution_pipeline.metrics as M
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pipe_src = (repo / 'src/swin2sr_super_resolution_pipeline/pipeline.py').read_text()
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'asserts': [(i, l.strip()) for i in code if i not in (5, 7, 9) for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'adapt_initial_state_from_live_model': 'frozen_state = {k: v.detach().clone() for k, v in model.state_dict().items() if k in name_set}' in pipe_src,
    'epoch0_note_frozen_model': '"note": "frozen model"' in pipe_src}

# P2 fetch the 360 pinned photographs, rebuild pairs and split, recompute the non-neural baselines
t0 = time.time()
files = S.fetch_corpus(cache_dir=str(out / 'inat-cache'))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
splits = {k: m['records'] for k, m in man.items()}
disj = S.check_split_disjoint(splits)
test = splits['test']
bn, bb = M.nearest_baseline(test), M.bicubic_baseline(test)
R['P2_sample'] = {'photographs': len(corpus), 'bytes': sum(len(v) for v in files.values()), 'pinned_bytes': S.CORPUS_BYTES, 'fetch_and_build_seconds': round(time.time() - t0, 1),
    'split_sizes': {k: len(v) for k, v in splits.items()}, 'disjoint': disj, 'observer_overlap': S.observer_overlap(splits),
    'dataset_digest_all_splits': S.dataset_digest([r for v in splits.values() for r in v]), 'pinned_SAMPLE_DIGEST': S.SAMPLE_DIGEST,
    'nearest_test': {'psnr': round(bn['psnr'], 2), 'ssim': round(bn['ssim'], 3)}, 'bicubic_test': {'psnr': round(bb['psnr'], 2), 'ssim': round(bb['ssim'], 3)},
    'recorded_kaggle': {'nearest': {'psnr': 25.29, 'ssim': 0.764}, 'bicubic': {'psnr': 26.31, 'ssim': 0.797}, 'frozen': {'psnr': 25.92, 'ssim': 0.785}, 'adapted': {'psnr': 26.91, 'ssim': 0.816}},
    'bicubic_per_species_psnr': {c: round(v['psnr'], 2) for c, v in bb['per_category'].items()}}

from collections import defaultdict
_obs = defaultdict(list)
for _r in S.SAMPLE_RECORDS: _obs[_r[1]].append(_r[4])
R['P2_sample']['observers_per_species_(photos, distinct)'] = {k: (len(v), len(set(v))) for k, v in _obs.items()}
R['P2_sample']['distinct_observers_total'] = len({_r[4] for _r in S.SAMPLE_RECORDS})

# P3 BYOD: effective minimum and loader matrix through cell 13's sequence
def jpg(i, size=(400, 300)):
    rng = np.random.default_rng(i); a = (rng.random((size[1], size[0], 3)) * 255).astype(np.uint8)
    b = io.BytesIO(); Image.fromarray(a).save(b, 'JPEG', quality=90); return b.getvalue()
def mkzip(path, files):
    with zipfile.ZipFile(path, 'w') as z:
        for n, d in files.items(): z.writestr(n, d)
    return path
def nb_byod(zp):
    recs = S.load_byod_dataset(zp); sp = S.split_dataset(recs, seed=42)
    m = {k: S.validate_dataset(v) for k, v in sp.items()}; S.check_split_disjoint({k: x['records'] for k, x in m.items()})
    return {'loaded': len(recs), **{k: x['n_records'] for k, x in m.items()}}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:200]}
zd = out / 'zips'; zd.mkdir(exist_ok=True)
smallest = None
for n in range(8, 80):
    r = run('n', lambda n=n: nb_byod(mkzip(zd / 'scan.zip', {f'p{i}.jpg': jpg(i) for i in range(n)})))
    if r['verdict'] == 'accepted': smallest = n; break
samples_min = {n: run(f'{n} photos', lambda n=n: nb_byod(mkzip(zd / f'n{n}.zip', {f'p{i}.jpg': jpg(i) for i in range(n)}))) for n in (8, 12, 30, 50)}
base = {f'p{i}.jpg': jpg(i) for i in range(60)}
small = dict(base); small.update({f's{i}.jpg': jpg(100 + i, (150, 150)) for i in range(10)})
cases = {
    '60 photos': base,
    '60 photos + 10 smaller than 192 px': small,
    '60 photos, 20 of them 150 px (so 40 usable)': {**{k: v for k, v in list(base.items())[:40]}, **{f's{i}.jpg': jpg(200 + i, (150, 150)) for i in range(20)}},
    'macOS zip (__MACOSX/._p0.jpg)': {**base, '__MACOSX/._p0.jpg': b'\x00\x05\x16\x07'},
    'zip with README.txt': {**base, 'README.txt': b'hi'},
    'basename collision a/p0.jpg + b/p0.jpg': {**{('a/' + k): v for k, v in base.items()}, 'b/p0.jpg': jpg(999)},
    'labels.csv naming files with folders': {**{('imgs/' + k): v for k, v in base.items()}, 'labels.csv': ('id,file,category\n' + ''.join(f'x{i},imgs/p{i}.jpg,cat{i % 2}\n' for i in range(60))).encode()},
}
P3 = []
for name, f in cases.items():
    r = run(name, lambda f=f, name=name: nb_byod(mkzip(zd / (re.sub('[^a-z0-9]+', '_', name.lower())[:40] + '.zip'), f)))
    P3.append(r)
lab = S.load_byod_dataset(zd / (re.sub('[^a-z0-9]+', '_', 'labels.csv naming files with folders'.lower())[:40] + '.zip'))
coll = S.load_byod_dataset(zd / (re.sub('[^a-z0-9]+', '_', 'basename collision a/p0.jpg + b/p0.jpg'.lower())[:40] + '.zip'))
R['P3_byod'] = {'stated_minimum': '8 images', 'smallest_accepted': smallest, 'samples': samples_min, 'matrix': P3,
    'labels_with_folders_categories_applied': sum(1 for r in lab if r.get('category')), 'labels_with_folders_ids': [r['id'] for r in lab[:3]],
    'collision_records': len(coll), 'skipped_small_images_reported': 'no: load_byod_dataset returns only the kept records and cell 13 prints len(records)'}

# P4 upload branch of cell 13
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True'); head = c13.split('    records = load_byod_dataset')[0]
def exec_upload(up, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: up)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(out)
    try:
        ns = {'Path': Path, 'os': os}; exec(compile(head, 'cell13', 'exec'), ns); return ns.get('file_name')
    finally: os.chdir(cwd)
R['P4_upload'] = {'cancelled': run('cancelled', lambda: exec_upload({})), 'two files': run('two', lambda: exec_upload({'a.zip': b'PK', 'b.zip': b'PK'})),
    'outside Colab': run('outside', lambda: exec_upload(None, colab=False)), 'has_path_field': bool(re.search(r'BYOD_(PATH|ZIP)\s*=', src(13)))}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:7000])
